<?php
require __DIR__ ."/config.php";
class Sistema extends config {
    var $conn;
    var $count;
   
    function connect(){

        $this->conn= new PDO(DB_DRIVER.":host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME,DB_USER,DB_PASSWORD);
    }

    function query($sql){
        $this->conect();
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $datos=array();
        $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $datos = $stmt->fetchAll();
        return $datos;
    }
    function alert($tipo, $mensaje){
        $alerta =array();
        $alerta['tipo']=$tipo;
        $alerta['mensaje']=$mensaje;
        include __DIR__.'/views/alert.php';
    }
    function setCount($count){
        $this->count = $count;
    }
    function getCount(){
        return $this->count;
    }
    function upload($carpeta){
        if(in_array($_FILES['fotografia']['type'],$this->getImageType())){
            if($_FILES['fotografia']['size']<=$this->getImageSize()){
                $n=rand(1,1000000);
                $nombre_archivo =$n.$_FILES['fotografia']['size'].$_FILES['fotografia']['name'];
                $nombre_archivo=md5($nombre_archivo);
                // espatula 25.jpg
                // taladro.trupper x.jpg
                $extencion=explode('.',$_FILES['fotografia']['name']);
                $extencion=$extencion[sizeof($extencion)-1];
                $nombre_archivo=$nombre_archivo.'.'.$extencion;
                if(!file_exists('../uploads/'.$carpeta.'/'.$nombre_archivo)){
                    move_uploaded_file($_FILES['fotografia']['tmp_name'],'../uploads/'.$carpeta.'/'.$nombre_archivo);
                    return $nombre_archivo;
                }
            }
        }
        return false;
    }
}
?>
